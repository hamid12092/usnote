import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Send, Image, Mic, Heart } from 'lucide-react';
import { useAppStore } from '../../store/appStore';

export const MessageInput: React.FC = () => {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { addMessage, currentUser } = useAppStore();

  const handleSend = () => {
    if (message.trim() && currentUser) {
      addMessage({
        senderId: currentUser.id,
        content: message.trim(),
        type: 'text',
        delivered: true,
        read: false
      });
      setMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleImageSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && currentUser) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const imageUrl = event.target?.result as string;
        addMessage({
          senderId: currentUser.id,
          content: 'Photo',
          type: 'image',
          delivered: true,
          read: false,
          imageUrl
        });
      };
      reader.readAsDataURL(file);
    }
    // Reset the input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const quickReactions = ['💕', '😘', '🥰', '✨', '🌙', '☀️'];

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="bg-white dark:bg-dark-secondary border-t border-gray-200 dark:border-gray-700 px-6 py-4 flex-shrink-0"
    >
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Quick Reactions */}
      <div className="flex space-x-2 mb-3 overflow-x-auto">
        {quickReactions.map((emoji, index) => (
          <motion.button
            key={emoji}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: index * 0.05 }}
            whileHover={{ scale: 1.2 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              if (currentUser) {
                addMessage({
                  senderId: currentUser.id,
                  content: emoji,
                  type: 'text',
                  delivered: true,
                  read: false
                });
              }
            }}
            className="text-xl p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors flex-shrink-0"
          >
            {emoji}
          </motion.button>
        ))}
      </div>

      {/* Message Input */}
      <div className="flex items-end space-x-3">
        <div className="flex-1 relative">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="w-full px-4 py-3 pr-12 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-2xl focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
            rows={1}
            style={{ minHeight: '48px', maxHeight: '120px' }}
          />
          
          {/* Attachment buttons */}
          <div className="absolute right-3 bottom-3 flex space-x-1">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleImageSelect}
              className="p-1 text-gray-400 hover:text-secondary-500 transition-colors"
            >
              <Image className="w-5 h-5" />
            </motion.button>
          </div>
        </div>

        {/* Voice/Send Button */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={message.trim() ? handleSend : () => setIsRecording(!isRecording)}
          className={`p-3 rounded-full transition-all duration-300 flex-shrink-0 ${
            message.trim()
              ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white shadow-lg hover:shadow-xl'
              : isRecording
              ? 'bg-red-500 text-white animate-pulse'
              : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-300 dark:hover:bg-gray-600'
          }`}
        >
          {message.trim() ? (
            <Send className="w-5 h-5" />
          ) : (
            <Mic className="w-5 h-5" />
          )}
        </motion.button>
      </div>
    </motion.div>
  );
};