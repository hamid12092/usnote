import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format, isToday, isYesterday } from 'date-fns';
import { Check, CheckCheck } from 'lucide-react';
import { useAppStore } from '../../store/appStore';

export const MessageList: React.FC = () => {
  const { messages, currentUser, partner } = useAppStore();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const formatMessageTime = (date: Date) => {
    if (isToday(date)) return format(date, 'HH:mm');
    if (isYesterday(date)) return 'Yesterday';
    return format(date, 'MMM dd');
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
      <AnimatePresence>
        {messages.map((message, index) => {
          const isOwn = message.senderId === currentUser?.id;
          const sender = isOwn ? currentUser : partner;
          
          return (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ delay: index * 0.05 }}
              className={`flex items-end space-x-2 ${isOwn ? 'justify-end' : 'justify-start'}`}
            >
              {/* Avatar for partner messages */}
              {!isOwn && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: index * 0.05 + 0.1 }}
                  className="flex-shrink-0 mb-1"
                >
                  <img
                    src={sender?.avatar}
                    alt={sender?.name}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                </motion.div>
              )}

              <div className={`max-w-xs lg:max-w-md ${isOwn ? 'order-2' : 'order-1'}`}>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className={`relative px-4 py-3 rounded-2xl ${
                    isOwn 
                      ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-br-md' 
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded-bl-md'
                  } shadow-sm`}
                >
                  {/* Image message */}
                  {message.type === 'image' && message.imageUrl && (
                    <div className="mb-2">
                      <img
                        src={message.imageUrl}
                        alt="Shared image"
                        className="max-w-full h-auto rounded-lg object-cover max-h-64"
                      />
                    </div>
                  )}
                  
                  {/* Text content */}
                  {message.content && message.type !== 'image' && (
                    <p className="text-sm leading-relaxed break-words">{message.content}</p>
                  )}
                  
                  <div className={`flex items-center justify-end mt-2 space-x-1 ${
                    isOwn ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'
                  }`}>
                    <span className="text-xs">
                      {formatMessageTime(message.timestamp)}
                    </span>
                    {isOwn && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: 0.2 }}
                      >
                        {message.read ? (
                          <CheckCheck className="w-4 h-4 text-secondary-300" />
                        ) : (
                          <Check className="w-4 h-4" />
                        )}
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              </div>

              {/* Avatar for own messages */}
              {isOwn && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: index * 0.05 + 0.1 }}
                  className="flex-shrink-0 mb-1"
                >
                  <img
                    src={sender?.avatar}
                    alt={sender?.name}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </AnimatePresence>
      <div ref={messagesEndRef} />
    </div>
  );
};