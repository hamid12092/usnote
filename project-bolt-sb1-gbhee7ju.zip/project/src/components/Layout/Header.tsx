import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Settings, Moon, Sun } from 'lucide-react';
import { useAppStore } from '../../store/appStore';

interface HeaderProps {
  onSettingsClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSettingsClick }) => {
  const { currentUser, partner, isConnected, darkMode, toggleDarkMode } = useAppStore();

  return (
    <motion.header 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="relative bg-white/90 dark:bg-dark-primary/90 backdrop-blur-lg border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex-shrink-0"
    >
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* Logo & Connection Status */}
        <div className="flex items-center space-x-4">
          <motion.div
            animate={{ 
              scale: isConnected ? [1, 1.1, 1] : 1,
              rotate: isConnected ? [0, 5, -5, 0] : 0
            }}
            transition={{ 
              duration: 2,
              repeat: isConnected ? Infinity : 0,
              repeatType: "reverse"
            }}
            className="relative"
          >
            <Heart className={`w-8 h-8 ${isConnected ? 'text-primary-500 animate-glow' : 'text-gray-400'} fill-current`} />
            {isConnected && (
              <motion.div
                animate={{ scale: [1, 1.5, 1], opacity: [0.7, 0, 0.7] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 w-8 h-8 bg-primary-500 rounded-full blur-sm"
              />
            )}
          </motion.div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">BondLens</h1>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              {isConnected ? 'Connected' : 'Connecting...'}
            </p>
          </div>
        </div>

        {/* Partner Status */}
        {partner && (
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex items-center space-x-3"
          >
            <div className="text-right">
              <p className="font-medium text-gray-900 dark:text-white">{partner.name}</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">
                {partner.isOnline ? 'Online now' : 'Last seen 5m ago'}
              </p>
            </div>
            <div className="relative">
              <img 
                src={partner.avatar} 
                alt={partner.name}
                className="w-10 h-10 rounded-full object-cover border-2 border-primary-500"
              />
              <motion.div
                animate={{ scale: partner.isOnline ? [1, 1.2, 1] : 1 }}
                transition={{ duration: 2, repeat: Infinity }}
                className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-dark-primary ${
                  partner.isOnline ? 'bg-green-500' : 'bg-gray-400'
                }`}
              />
            </div>
          </motion.div>
        )}

        {/* Settings */}
        <div className="flex items-center space-x-2">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            {darkMode ? <Sun className="w-5 h-5 text-yellow-500" /> : <Moon className="w-5 h-5 text-gray-600" />}
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onSettingsClick}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          </motion.button>
        </div>
      </div>
    </motion.header>
  );
};