import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Heart, Plus } from 'lucide-react';
import { format } from 'date-fns';
import { useAppStore } from '../../store/appStore';

export const MemoryWeaver: React.FC = () => {
  const { sharedMoments, addSharedMoment } = useAppStore();

  const handleAddMoment = () => {
    const newMoment = {
      title: 'New Shared Memory',
      description: 'Another beautiful moment together',
      images: ['https://images.pexels.com/photos/3617500/pexels-photo-3617500.jpeg?auto=compress&cs=tinysrgb&w=800'],
      location: 'Our Hearts',
      mutualEngagement: Math.floor(Math.random() * 20) + 80
    };
    addSharedMoment(newMoment);
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="bg-white dark:bg-dark-secondary rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Memory Weaver
        </h3>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleAddMoment}
          className="p-2 bg-primary-500 text-white rounded-xl hover:bg-primary-600 transition-colors"
        >
          <Plus className="w-5 h-5" />
        </motion.button>
      </div>

      <div className="space-y-4">
        {sharedMoments.map((moment, index) => (
          <motion.div
            key={moment.id}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
            className="relative bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-xl p-4 border border-primary-200 dark:border-primary-700/50"
          >
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0">
                <img
                  src={moment.images[0]}
                  alt={moment.title}
                  className="w-16 h-16 rounded-lg object-cover"
                />
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-1">
                  {moment.title}
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  {moment.description}
                </p>
                
                <div className="flex items-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-3 h-3" />
                    <span>{format(moment.timestamp, 'MMM dd')}</span>
                  </div>
                  
                  {moment.location && (
                    <div className="flex items-center space-x-1">
                      <MapPin className="w-3 h-3" />
                      <span>{moment.location}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center space-x-1">
                    <Heart className="w-3 h-3 text-primary-500 fill-current" />
                    <span>{moment.mutualEngagement}%</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Engagement indicator */}
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${moment.mutualEngagement}%` }}
              transition={{ duration: 1, delay: index * 0.2 }}
              className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-bl-xl"
            />
          </motion.div>
        ))}
      </div>

      {sharedMoments.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-8"
        >
          <Heart className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
          <p className="text-gray-500 dark:text-gray-400">
            Start creating beautiful memories together
          </p>
        </motion.div>
      )}
    </motion.div>
  );
};