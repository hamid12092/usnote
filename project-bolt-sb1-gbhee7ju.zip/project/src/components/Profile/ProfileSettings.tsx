import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Camera, Save, Moon, Sun, Bell, Shield, Heart, Palette } from 'lucide-react';
import { useAppStore } from '../../store/appStore';

export const ProfileSettings: React.FC = () => {
  const { currentUser, partner, darkMode, toggleDarkMode, setCurrentUser } = useAppStore();
  const [editableName, setEditableName] = useState(currentUser?.name || '');
  const [editableAvatar, setEditableAvatar] = useState(currentUser?.avatar || '');
  const [editableMood, setEditableMood] = useState(currentUser?.mood || '💕');
  const [notifications, setNotifications] = useState(true);
  const [privacy, setPrivacy] = useState(true);

  const handleSaveProfile = () => {
    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        name: editableName,
        avatar: editableAvatar,
        mood: editableMood
      });
    }
  };

  const moods = ['💕', '😘', '🥰', '✨', '🌙', '☀️', '🎉', '😊', '💖', '🌈'];

  const settingsSections = [
    {
      title: 'Profile',
      icon: User,
      items: [
        {
          label: 'Name',
          type: 'input',
          value: editableName,
          onChange: setEditableName
        },
        {
          label: 'Avatar URL',
          type: 'input',
          value: editableAvatar,
          onChange: setEditableAvatar
        },
        {
          label: 'Current Mood',
          type: 'mood',
          value: editableMood,
          onChange: setEditableMood
        }
      ]
    },
    {
      title: 'Appearance',
      icon: Palette,
      items: [
        {
          label: 'Dark Mode',
          type: 'toggle',
          value: darkMode,
          onChange: toggleDarkMode
        }
      ]
    },
    {
      title: 'Notifications',
      icon: Bell,
      items: [
        {
          label: 'Push Notifications',
          type: 'toggle',
          value: notifications,
          onChange: setNotifications
        }
      ]
    },
    {
      title: 'Privacy',
      icon: Shield,
      items: [
        {
          label: 'Share Activity Status',
          type: 'toggle',
          value: privacy,
          onChange: setPrivacy
        }
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6 h-full overflow-y-auto">
      {/* Profile Header */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-white dark:bg-dark-secondary rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
      >
        <div className="flex items-center space-x-6">
          <div className="relative">
            <img
              src={editableAvatar}
              alt={editableName}
              className="w-24 h-24 rounded-full object-cover border-4 border-primary-500"
            />
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="absolute -bottom-2 -right-2 bg-primary-500 text-white p-2 rounded-full cursor-pointer"
            >
              <Camera className="w-4 h-4" />
            </motion.div>
          </div>
          
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {editableName}
            </h2>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-2xl">{editableMood}</span>
                <span className="text-sm text-gray-600 dark:text-gray-400">Current mood</span>
              </div>
              {partner && (
                <div className="flex items-center space-x-2">
                  <Heart className="w-4 h-4 text-primary-500" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    Connected to {partner.name}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Settings Sections */}
      {settingsSections.map((section, sectionIndex) => (
        <motion.div
          key={section.title}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: sectionIndex * 0.1 }}
          className="bg-white dark:bg-dark-secondary rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
        >
          <div className="flex items-center space-x-3 mb-6">
            <section.icon className="w-6 h-6 text-primary-500" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              {section.title}
            </h3>
          </div>

          <div className="space-y-4">
            {section.items.map((item, itemIndex) => (
              <div key={item.label} className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {item.label}
                </label>
                
                {item.type === 'input' && (
                  <input
                    type="text"
                    value={item.value as string}
                    onChange={(e) => item.onChange(e.target.value)}
                    className="px-3 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent text-gray-900 dark:text-white text-sm max-w-xs"
                  />
                )}
                
                {item.type === 'toggle' && (
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => item.onChange(!item.value)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      item.value ? 'bg-primary-500' : 'bg-gray-300 dark:bg-gray-600'
                    }`}
                  >
                    <motion.span
                      animate={{ x: item.value ? 20 : 2 }}
                      className="inline-block h-4 w-4 transform rounded-full bg-white shadow-lg transition-transform"
                    />
                  </motion.button>
                )}
                
                {item.type === 'mood' && (
                  <div className="flex space-x-2">
                    {moods.map((mood) => (
                      <motion.button
                        key={mood}
                        whileHover={{ scale: 1.2 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => item.onChange(mood)}
                        className={`text-xl p-2 rounded-full transition-colors ${
                          item.value === mood 
                            ? 'bg-primary-100 dark:bg-primary-900/30 ring-2 ring-primary-500' 
                            : 'hover:bg-gray-100 dark:hover:bg-gray-700'
                        }`}
                      >
                        {mood}
                      </motion.button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </motion.div>
      ))}

      {/* Save Button */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleSaveProfile}
        className="w-full bg-gradient-to-r from-primary-500 to-primary-600 text-white py-4 rounded-2xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center space-x-2"
      >
        <Save className="w-5 h-5" />
        <span>Save Profile</span>
      </motion.button>

      {/* Relationship Stats */}
      {partner && (
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="bg-white dark:bg-dark-secondary rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Relationship Stats
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-primary-50 dark:bg-primary-900/20 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                247
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Days Together
              </div>
            </div>
            <div className="bg-secondary-50 dark:bg-secondary-900/20 rounded-xl p-4 text-center">
              <div className="text-2xl font-bold text-secondary-600 dark:text-secondary-400">
                1,432
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Messages Sent
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};