import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, MapPin } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { format } from 'date-fns';

export const PresencePulse: React.FC = () => {
  const { currentUser, partner } = useAppStore();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getTimezoneTime = (timezone: string) => {
    return new Date().toLocaleString('en-US', { 
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.3 }}
      className="bg-white dark:bg-dark-secondary rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
    >
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
        Presence Pulse
      </h3>

      <div className="space-y-6">
        {/* Synchronized Heartbeat */}
        <div className="text-center">
          <motion.div
            animate={{ 
              scale: [1, 1.2, 1],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ 
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full mb-4"
          >
            <Heart className="w-10 h-10 text-white fill-current" />
          </motion.div>
          
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Hearts beating in sync
          </p>
          
          <div className="flex justify-center space-x-2 mt-2">
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.3, 1, 0.3]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: i * 0.2
                }}
                className="w-2 h-2 bg-primary-500 rounded-full"
              />
            ))}
          </div>
        </div>

        {/* Timezone Display */}
        <div className="grid grid-cols-2 gap-4">
          {currentUser && (
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-primary-50 dark:bg-primary-900/20 rounded-xl p-4 text-center border border-primary-200 dark:border-primary-700/50"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-12 h-12 rounded-full mx-auto mb-2 object-cover"
              />
              <p className="font-medium text-gray-900 dark:text-white text-sm">
                {currentUser.name}
              </p>
              <p className="text-lg font-bold text-primary-600 dark:text-primary-400">
                {getTimezoneTime(currentUser.timezone)}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center justify-center">
                <MapPin className="w-3 h-3 mr-1" />
                {currentUser.timezone.split('/')[1]}
              </p>
            </motion.div>
          )}

          {partner && (
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-secondary-50 dark:bg-secondary-900/20 rounded-xl p-4 text-center border border-secondary-200 dark:border-secondary-700/50"
            >
              <div className="relative inline-block mb-2">
                <img
                  src={partner.avatar}
                  alt={partner.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <motion.div
                  animate={{ scale: partner.isOnline ? [1, 1.2, 1] : 1 }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-dark-secondary ${
                    partner.isOnline ? 'bg-green-500' : 'bg-gray-400'
                  }`}
                />
              </div>
              <p className="font-medium text-gray-900 dark:text-white text-sm">
                {partner.name}
              </p>
              <p className="text-lg font-bold text-secondary-600 dark:text-secondary-400">
                {getTimezoneTime(partner.timezone)}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center justify-center">
                <MapPin className="w-3 h-3 mr-1" />
                {partner.timezone.split('/')[1]}
              </p>
            </motion.div>
          )}
        </div>

        {/* Mood Sync */}
        <div className="bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-xl p-4">
          <h4 className="font-medium text-gray-900 dark:text-white mb-3 text-center">
            Current Mood
          </h4>
          <div className="flex justify-center space-x-8">
            {currentUser && (
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-center"
              >
                <div className="text-3xl mb-1">{currentUser.mood}</div>
                <p className="text-xs text-gray-600 dark:text-gray-400">You</p>
              </motion.div>
            )}
            
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="flex items-center"
            >
              <Heart className="w-6 h-6 text-primary-500 fill-current" />
            </motion.div>
            
            {partner && (
              <motion.div
                animate={{ rotate: [0, -10, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
                className="text-center"
              >
                <div className="text-3xl mb-1">{partner.mood}</div>
                <p className="text-xs text-gray-600 dark:text-gray-400">{partner.name}</p>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};