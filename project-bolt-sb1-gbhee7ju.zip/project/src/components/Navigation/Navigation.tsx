import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Heart, Camera, Settings, User } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Heart },
    { id: 'messages', label: 'Messages', icon: MessageCircle },
    { id: 'memories', label: 'Memories', icon: Camera },
    { id: 'profile', label: 'Profile', icon: User }
  ];

  return (
    <motion.nav
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="bg-white dark:bg-dark-secondary border-t border-gray-200 dark:border-gray-700 px-6 py-2"
    >
      <div className="flex justify-around max-w-md mx-auto">
        {tabs.map((tab, index) => (
          <motion.button
            key={tab.id}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => onTabChange(tab.id)}
            className={`relative flex flex-col items-center py-2 px-4 rounded-xl transition-all duration-300 ${
              activeTab === tab.id
                ? 'text-primary-500'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            <tab.icon className="w-6 h-6 mb-1" />
            <span className="text-xs font-medium">{tab.label}</span>
            
            {activeTab === tab.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 bg-primary-50 dark:bg-primary-900/30 rounded-xl border border-primary-200 dark:border-primary-700/50"
                initial={false}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            )}
          </motion.button>
        ))}
      </div>
    </motion.nav>
  );
};