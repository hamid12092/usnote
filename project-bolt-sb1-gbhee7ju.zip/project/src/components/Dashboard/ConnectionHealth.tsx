import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Camera, Clock } from 'lucide-react';
import { useAppStore } from '../../store/appStore';

export const ConnectionHealth: React.FC = () => {
  const { messages, sharedMoments } = useAppStore();
  
  const healthMetrics = [
    {
      icon: MessageCircle,
      label: 'Messages',
      value: messages.length,
      color: 'text-secondary-500',
      bgColor: 'bg-secondary-50 dark:bg-secondary-900/20'
    },
    {
      icon: Camera,
      label: 'Moments',
      value: sharedMoments.length,
      color: 'text-purple-500',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20'
    },
    {
      icon: Clock,
      label: 'Streak',
      value: 12,
      color: 'text-orange-500',
      bgColor: 'bg-orange-50 dark:bg-orange-900/20'
    }
  ];

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.1 }}
      className="bg-white dark:bg-dark-secondary rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700"
    >
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
        Activity Overview
      </h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {healthMetrics.map((metric, index) => (
          <motion.div
            key={metric.label}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.05 }}
            className={`${metric.bgColor} rounded-xl p-4 text-center transition-all duration-300`}
          >
            <motion.div
              animate={{ 
                rotate: [0, 5, -5, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                delay: index * 0.5
              }}
            >
              <metric.icon className={`w-8 h-8 ${metric.color} mx-auto mb-2`} />
            </motion.div>
            <div className={`text-2xl font-bold ${metric.color} mb-1`}>
              {metric.value}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              {metric.label}
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};