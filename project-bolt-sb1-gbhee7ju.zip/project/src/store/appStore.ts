import { create } from 'zustand';

interface User {
  id: string;
  name: string;
  avatar: string;
  timezone: string;
  lastSeen: Date;
  isOnline: boolean;
  mood: string;
}

interface Message {
  id: string;
  senderId: string;
  content: string;
  type: 'text' | 'image' | 'voice';
  timestamp: Date;
  delivered: boolean;
  read: boolean;
  imageUrl?: string;
}

interface SharedMoment {
  id: string;
  title: string;
  description: string;
  images: string[];
  location?: string;
  timestamp: Date;
  mutualEngagement: number;
}

interface AppState {
  currentUser: User | null;
  partner: User | null;
  messages: Message[];
  sharedMoments: SharedMoment[];
  isConnected: boolean;
  darkMode: boolean;
  
  // Actions
  setCurrentUser: (user: User) => void;
  setPartner: (partner: User) => void;
  addMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  markMessageAsRead: (messageId: string) => void;
  addSharedMoment: (moment: Omit<SharedMoment, 'id' | 'timestamp'>) => void;
  setConnectionStatus: (status: boolean) => void;
  toggleDarkMode: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentUser: {
    id: '1',
    name: 'Alex',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    timezone: 'America/New_York',
    lastSeen: new Date(),
    isOnline: true,
    mood: '💕'
  },
  partner: {
    id: '2',
    name: 'Jordan',
    avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
    timezone: 'Europe/London',
    lastSeen: new Date(Date.now() - 300000), // 5 minutes ago
    isOnline: false,
    mood: '✨'
  },
  messages: [
    {
      id: '1',
      senderId: '2',
      content: 'Good morning my love! Just had the most amazing coffee thinking of you ☕️💕',
      type: 'text',
      timestamp: new Date(Date.now() - 3600000),
      delivered: true,
      read: true
    },
    {
      id: '2',
      senderId: '1',
      content: 'Aww that sounds perfect! I wish I could share that moment with you 🥰',
      type: 'text',
      timestamp: new Date(Date.now() - 3000000),
      delivered: true,
      read: true
    }
  ],
  sharedMoments: [
    {
      id: '1',
      title: 'Our Virtual Date Night',
      description: 'Watched the sunset "together" while video calling',
      images: ['https://images.pexels.com/photos/1598073/pexels-photo-1598073.jpeg?auto=compress&cs=tinysrgb&w=800'],
      location: 'Paris & New York',
      timestamp: new Date(Date.now() - 86400000),
      mutualEngagement: 95
    }
  ],
  isConnected: true,
  darkMode: false,

  setCurrentUser: (user) => set({ currentUser: user }),
  setPartner: (partner) => set({ partner }),
  addMessage: (messageData) => set((state) => ({
    messages: [...state.messages, {
      ...messageData,
      id: Date.now().toString(),
      timestamp: new Date()
    }]
  })),
  markMessageAsRead: (messageId) => set((state) => ({
    messages: state.messages.map(msg => 
      msg.id === messageId ? { ...msg, read: true } : msg
    )
  })),
  addSharedMoment: (momentData) => set((state) => ({
    sharedMoments: [...state.sharedMoments, {
      ...momentData,
      id: Date.now().toString(),
      timestamp: new Date()
    }]
  })),
  setConnectionStatus: (status) => set({ isConnected: status }),
  toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode }))
}));