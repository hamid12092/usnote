import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Header } from './components/Layout/Header';
import { Navigation } from './components/Navigation/Navigation';
import { ConnectionHealth } from './components/Dashboard/ConnectionHealth';
import { MemoryWeaver } from './components/Memory/MemoryWeaver';
import { PresencePulse } from './components/Presence/PresencePulse';
import { MessageList } from './components/Messaging/MessageList';
import { MessageInput } from './components/Messaging/MessageInput';
import { ProfileSettings } from './components/Profile/ProfileSettings';
import { useAppStore } from './store/appStore';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const { darkMode } = useAppStore();

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6 h-full"
          >
            <ConnectionHealth />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <MemoryWeaver />
              <PresencePulse />
            </div>
          </motion.div>
        );
      
      case 'messages':
        return (
          <motion.div
            key="messages"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="h-full bg-white dark:bg-dark-secondary rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700 flex flex-col overflow-hidden"
          >
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Messages
              </h2>
            </div>
            <MessageList />
            <MessageInput />
          </motion.div>
        );
      
      case 'memories':
        return (
          <motion.div
            key="memories"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 h-full"
          >
            <MemoryWeaver />
            <div className="bg-white dark:bg-dark-secondary rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Photo Gallery
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[1, 2, 3, 4].map((i) => (
                  <motion.div
                    key={i}
                    whileHover={{ scale: 1.05 }}
                    className="aspect-square bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30 rounded-xl flex items-center justify-center"
                  >
                    <span className="text-2xl">📸</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        );
      
      case 'profile':
        return (
          <motion.div
            key="profile"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="h-full flex flex-col"
          >
            <ProfileSettings />
          </motion.div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-dark-primary dark:to-dark-accent transition-colors duration-300">
      <Header onSettingsClick={() => setActiveTab('profile')} />
      
      <main className="flex-1 overflow-y-auto container mx-auto px-6 py-6 pb-24">
        <AnimatePresence mode="wait">
          {renderTabContent()}
        </AnimatePresence>
      </main>
      
      <div className="fixed bottom-0 left-0 right-0 z-50 flex-shrink-0">
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </div>
  );
}

export default App;